---
Title: Lesser_Deities
Type: Pantheon
Directory: Lore/Lesser_Deities
Planes:
  - Material
  - Ethereal
  - Astral
  - Celestial
Pantheon: Lesser_Deities
Pantheon_Name: Lesser
Deities:
  - Lunessa
  - Vaelreth
  - Seramara
  - Kaelis
  - Tahrun
  - Xexas
  - Vandryl
Associated_Fellowships:
  - Veilbound
  - Moonlit Striders
  - Echoes of Lunessa
  - Ashen Circle
  - Keepers of the Brand
  - Scorchbearers
  - Order of the Crimson Veil
  - The Unforgotten
  - Seramara’s Thorn
  - Emberwilds
  - The Chainbreakers
  - Stagblood Pact
  - The Whispering Quill
  - Circle of the Folded Veil
  - The Drowned Eye
  - Bladed Veil
  - Children of the Second Tongue
  - Lachrymists
  - Order of the Pale Gift
  - Merciful Hands
  - Duskborn Choir
tags:
  - pantheon
  - lesser_deity
  - lesser_deities
  - index
  - fellowships
---

# Lesser Deities

The Lesser Deities are still immortal, but they have not always been so. These were once mortals who embodied the very principles and teachings of their respective Gods so perfectly that they were divinity in their lifetime, and thus, ascended to the Celestial plane. They are given a choice of their own avatar to appear on the mortal plane when needed. This avatar can be how they appeared in mortality, or it can be another form of their choosing, but they cannot alter their avatar after their decision. Killing a lesser deity is achievable, but it is still a herculean feat and has never been done before. Doing so would require great effort, and it would need to take place within the Celestial plane to be permanent. I currently have no Lesser Deities created, but I want to create them. I know that I want one to be of the moon, but I have not worked out the details. I need help with Lesser Deities, the Hells, the Abyss, and my elemental gods.

Mortals who embodied their Greater Deity's teachings with such piety that they were given Ascension and granted Divinity. These would be akin to Demigods. Internal links are provided to the respective Deity files.

- [[Lunessa]] – Goddess of Moonlight, Secrets, and Cycles
- [[Vaelreth]] – God of Vengeance and Justice
- [[Seramara]] – Goddess of Love, Grief, and Memory
- [[Kaelis]] – God of Freedom, Chaos, and Revelry
- [[Tahrun]] – God of Dreams, Madness, and Prophecy
- [[Xexas]] – God of Poison, Treachery, and Beautiful Lies
- [[Vandryl]] – God of Undeath, Despair, and Forbidden Mercy