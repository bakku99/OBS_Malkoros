---
Title: Lower_Planes_Deities
Type: Pantheon
Directory: Lore/Lower_Planes_Deities
Planes:
  - Lower
  - Abyss
  - Nine Hells
Pantheon: Lower_Planes_Deities
Pantheon_Name: Lower
Deities:
  - Azhadûn
  - Ulvaarak
Associated_Fellowships:
  - The Chainforged
  - Accorded Eyes
  - The Order of the Final Clause
  - Maws of the Thousand
  - Gorehowlers
  - Children of Shard-Flesh
tags:
  - pantheon
  - lower_planes_deity
  - lower_planes_deities
  - index
  - fellowships
---

# Lower Planes Deities

The Greater Deities of the Hells and the Abyss. Internal links are provided to the respective Deity files.

- [[Azhadûn]] - Greater God of Tyranny, Contracts, and Damnation
- [[Ulvaarak]] - Greater God of Madness, Ruin, and Endless Hunger