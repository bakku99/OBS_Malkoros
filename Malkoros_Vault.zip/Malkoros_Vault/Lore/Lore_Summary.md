# Lore Summary

