---
Title: Cinderscribes
Type: Fellowship
Directory: Lore/Fellowships/Cinderscribes
Category:
  - Fellowship
  - Organizations
Patron Deity: Pyrius
Planes:
  - Elemental
  - Fire
Pantheon: Elemental_Deities
Associated_Fellowships:
  - Burning Sons
  - The Ashen Conclave
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - pyrius
---

# Cinderscribes


Chroniclers of transformation who use flame to create impermanent masterpieces, from architecture to living beings. They believe true art can only be born in flame — and must also die in it.
[[Pyrius]]
