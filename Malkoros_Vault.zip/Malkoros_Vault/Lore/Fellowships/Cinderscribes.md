---
Patron Deity: Pyrius
---

# Cinderscribes


Chroniclers of transformation who use flame to create impermanent masterpieces, from architecture to living beings. They believe true art can only be born in flame — and must also die in it.
[[Pyrius]]
