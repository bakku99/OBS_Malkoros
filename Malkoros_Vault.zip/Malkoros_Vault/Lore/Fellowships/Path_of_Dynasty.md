---
Patron Deity: Ineas
---

# Path of Dynasty


This path seeks the enlightenment and power of knowledge, secrets, and lore. Walkers of this path, or Lords, seek to know everything and anything. They are brokers of secrets of people, places, and things. Their knowledge and curiousity is vast as their libraries and memories. Many a king or noble lord has been aided and defeated by the Lords. The Lords rarely talk amongst each other, for fear of losing secrets to another; however, they do gather every few years in Arman to speak of what they have learned, sometimes to check for pieces they may not have.
[[Ineas]]
