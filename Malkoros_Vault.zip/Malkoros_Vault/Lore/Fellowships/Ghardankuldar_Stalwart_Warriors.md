---
Patron Deity: Therassor
---

# Ghardankuldar Stalwart Warriors


Born in the dwarven halls of Hughfaruhm and Degh Kuldohr, the warlike dwarves fought amongst themselves and others. As the blood flowed like rivers under the great mountains, the wise warchiefs sought a moral code to follow to end the chaos and strengthen their warriors against outside threats. Coming in a vision was Therassor, guised as the dwarven warrior-king Ghardan Aglar (Stalwart Blade). He battled their greatest of warriors and granted them with his teachings. Their sense of honor awakened, they gathered into an incredible force seeking to bring down the tyranny of poor leaders, end the unethical fighting of mercenaries, and stop the dark tide of Othys's armies. Now many humans have joined the Stalwart Warriors.
[[Therassor]]
