---
Patron Deity: Myrradyn
---

# The Loomwalkers


Planar travelers and spell-weavers who study how magic ties all things together. They believe every spell cast is a ripple across the true Weave, and they seek to learn its original language.
[[Myrradyn]]
