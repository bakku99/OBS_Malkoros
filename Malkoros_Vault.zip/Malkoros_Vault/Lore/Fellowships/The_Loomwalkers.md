---
Title: The_Loomwalkers
Type: Fellowship
Directory: Lore/Fellowships/The_Loomwalkers
Category:
  - Fellowship
  - Organizations
Patron Deity: Myrradyn
Planes:
  - Elemental
  - Arcane
Pantheon: Elemental_Deities
Associated_Fellowships:
  - Inkborn Choir
  - Fractaline Circle
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - myrradyn
---

# The Loomwalkers


Planar travelers and spell-weavers who study how magic ties all things together. They believe every spell cast is a ripple across the true Weave, and they seek to learn its original language.
[[Myrradyn]]
