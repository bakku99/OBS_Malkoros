---
Title: Lovers_of_Fortune
Type: Fellowship
Directory: Lore/Fellowships/Lovers_of_Fortune
Category:
  - Fellowship
  - Organizations
Patron Deity: Atotz
Planes:
  - Material
  - Ethereal
  - Astral
  - Celestial
Pantheon: Greater_Deities
Associated_Fellowships:
  - Laughing Maidens
  - Spinning Stars
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - atotz
---

# Lovers of Fortune


Many people believe the Lovers are one of the most frightening and stupid groups of people on the face of Malkoros. These followers of Atotz literally throw themselves into dangerous situations, be it leaping from tall cliffs, mooing like a cow to a minotaur, or running into a dragon's maw. It is through their acceptance of chance and the luck of their goddess that they survive. Though, the course of the Lovers' history includes many who have fallen in the service of the Scarlet Mistress.
[[Atotz]]
