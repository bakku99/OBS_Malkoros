---
Patron Deity: Kaelis
---

# Stagblood Pact


A savage fellowship of berserkers and beastkin who embrace the primal essence of Kaelis. They dance under moonlight, howl in battle, and believe the wilderness itself is sacred and ungovernable.
[[Kaelis]]
