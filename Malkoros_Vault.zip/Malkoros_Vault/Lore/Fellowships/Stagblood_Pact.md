---
Title: Stagblood_Pact
Type: Fellowship
Directory: Lore/Fellowships/Stagblood_Pact
Category:
  - Fellowship
  - Organizations
Patron Deity: Kaelis
Planes:
  - Material
  - Ethereal
  - Astral
  - Celestial
Pantheon: Lesser_Deities
Associated_Fellowships:
  - Emberwilds
  - The Chainbreakers
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - kaelis
---

# Stagblood Pact


A savage fellowship of berserkers and beastkin who embrace the primal essence of Kaelis. They dance under moonlight, howl in battle, and believe the wilderness itself is sacred and ungovernable.
[[Kaelis]]
