---
Title: Order_of_the_Crimson_Veil
Type: Fellowship
Directory: Lore/Fellowships/Order_of_the_Crimson_Veil
Category:
  - Fellowship
  - Organizations
Patron Deity: Seramara
Planes:
  - Material
  - Ethereal
  - Astral
  - Celestial
Pantheon: Lesser_Deities
Associated_Fellowships:
  - Seramara’s Thorn
  - The Unforgotten
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - seramara
---

# Order of the Crimson Veil


A sacred group of griefwardens who preside over funerals, deliver last rites, and assist those who have lost loved ones. They are revered by the common folk and feared by necromancers.
[[Seramara]]
