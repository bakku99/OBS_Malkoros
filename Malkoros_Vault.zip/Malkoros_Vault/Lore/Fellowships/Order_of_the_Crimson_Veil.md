---
Patron Deity: Seramara
---

# Order of the Crimson Veil


A sacred group of griefwardens who preside over funerals, deliver last rites, and assist those who have lost loved ones. They are revered by the common folk and feared by necromancers.
[[Seramara]]
