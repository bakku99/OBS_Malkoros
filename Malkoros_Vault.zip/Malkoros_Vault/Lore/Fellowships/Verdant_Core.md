---
Patron Deity: Thavax
---

# Verdant Core


A secretive order of druids and earthspeakers who believe that Thavax slumbers at the heart of the world, and that the deeper one goes, the closer they come to understanding all things. Their roots lie in Caltorra’s deepest groves and caverns.
[[Thavax]]
