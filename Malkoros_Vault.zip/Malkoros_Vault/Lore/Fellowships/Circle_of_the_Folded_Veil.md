---
Patron Deity: Tahrun
---

# Circle of the Folded Veil


Dreamwalkers and planar navigators who use sleep to traverse realms beyond mortal comprehension. They are often insomniacs or narcoleptics, rarely fully awake or fully dreaming.
[[Tahrun]]
