---
Title: Circle_of_the_Folded_Veil
Type: Fellowship
Directory: Lore/Fellowships/Circle_of_the_Folded_Veil
Category:
  - Fellowship
  - Organizations
Patron Deity: Tahrun
Planes:
  - Material
  - Ethereal
  - Astral
  - Celestial
Pantheon: Lesser_Deities
Associated_Fellowships:
  - The Whispering Quill
  - The Drowned Eye
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - tahrun
---

# Circle of the Folded Veil


Dreamwalkers and planar navigators who use sleep to traverse realms beyond mortal comprehension. They are often insomniacs or narcoleptics, rarely fully awake or fully dreaming.
[[Tahrun]]
