---
Title: Eyes_of_the_Blazing_Sun
Type: Fellowship
Directory: Lore/Fellowships/Eyes_of_the_Blazing_Sun
Category:
  - Fellowship
  - Organizations
Patron Deity: Solanis
Planes:
  - Material
  - Ethereal
  - Astral
  - Celestial
Pantheon: Greater_Deities
Associated_Fellowships:
  - Dawnbringers
  - Knights of Aina'rutha
  - Society of Luminaries
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - solanis
---

# Eyes of the Blazing Sun


The Eyes seek out darkness in the world, be it of the heart or of the undead. They bring forth the words and will of Solanis to aid the world. These followers travel the world widely, erecting and maintaining churches and temples in many towns and cities. They are wise sages who balance charitable works, preaching, and warring against evil. This is the largest of Solanis' fellowships, with large temples in Isodora, Dramfark, Freya, and Lumella.
[[Solanis]]
