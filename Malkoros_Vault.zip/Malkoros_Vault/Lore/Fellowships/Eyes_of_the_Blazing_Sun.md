---
Patron Deity: Solanis
---

# Eyes of the Blazing Sun


The Eyes seek out darkness in the world, be it of the heart or of the undead. They bring forth the words and will of Solanis to aid the world. These followers travel the world widely, erecting and maintaining churches and temples in many towns and cities. They are wise sages who balance charitable works, preaching, and warring against evil. This is the largest of Solanis' fellowships, with large temples in Isodora, Dramfark, Freya, and Lumella.
[[Solanis]]
