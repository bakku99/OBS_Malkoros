---
Patron Deity: Uztix
---

# Walkers of the Serpentine Labyrinth


The Walkers build and rebuild the world and mythos around them in an attempt to lose all peoples in their webs. The minds and machinations of these followers are considered mad, but only because Uztix herself is the only true seer of their logic. Uztix began this sect to hide her plots and desires from the rest of the world. Over the ages, the small sect has gained other followers. Some in Uztix's church believe that the web connects all of her followers through their dark dreams and desires, but only the Walkers know the truth. New Walkers are rare indeed for this web, as they are selected only by Uztix herself.
[[Uztix]]
