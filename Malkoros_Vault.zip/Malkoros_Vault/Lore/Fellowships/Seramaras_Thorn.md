---
Patron Deity: Seramara
---

# Seramaras Thorn


A vengeful sect of lovers scorned or betrayed. They walk a darker road, believing that love defiled must be avenged. While controversial, they are protected by divine sanction — for even love's pain is sacred.
[[Seramara]]
