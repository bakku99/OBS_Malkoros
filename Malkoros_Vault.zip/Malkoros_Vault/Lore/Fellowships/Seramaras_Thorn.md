---
Title: Seramaras_Thorn
Type: Fellowship
Directory: Lore/Fellowships/Seramaras_Thorn
Category:
  - Fellowship
  - Organizations
Patron Deity: Seramara
Planes:
  - Material
  - Ethereal
  - Astral
  - Celestial
Pantheon: Lesser_Deities
Associated_Fellowships:
  - Order of the Crimson Veil
  - Seramara’s Thorn
  - The Unforgotten
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - seramara
---

# Seramaras Thorn


A vengeful sect of lovers scorned or betrayed. They walk a darker road, believing that love defiled must be avenged. While controversial, they are protected by divine sanction — for even love's pain is sacred.
[[Seramara]]
