---
Title: The_Chainbreakers
Type: Fellowship
Directory: Lore/Fellowships/The_Chainbreakers
Category:
  - Fellowship
  - Organizations
Patron Deity: Kaelis
Planes:
  - Material
  - Ethereal
  - Astral
  - Celestial
Pantheon: Lesser_Deities
Associated_Fellowships:
  - Emberwilds
  - Stagblood Pact
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - kaelis
---

# The Chainbreakers


Defiant warriors who liberate slaves, topple despots, and tear down systems of control. Their strikes are unpredictable, their tactics chaotic, but their results undeniable. A Chainbreaker leaves no crown uncracked.
[[Kaelis]]
