---
Patron Deity: Kaelis
---

# The Chainbreakers


Defiant warriors who liberate slaves, topple despots, and tear down systems of control. Their strikes are unpredictable, their tactics chaotic, but their results undeniable. A Chainbreaker leaves no crown uncracked.
[[Kaelis]]
