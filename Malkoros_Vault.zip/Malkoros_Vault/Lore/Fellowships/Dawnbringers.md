---
Title: Dawnbringers
Type: Fellowship
Directory: Lore/Fellowships/Dawnbringers
Category:
  - Fellowship
  - Organizations
Patron Deity: Solanis
Planes:
  - Material
  - Ethereal
  - Astral
  - Celestial
Pantheon: Greater_Deities
Associated_Fellowships:
  - Eyes of the Blazing Sun
  - Society of Luminaries
  - Knights of Aina'rutha
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - solanis
---

# Dawnbringer
Secretive and wary, the Dawnbringers infiltrate warrens of darkness to destroy and banish evil from the world. As their name states, they bring the light of Solanis into the heart of eternal night to bear it away. Their numbers are never truly known, though some of the greatest battles and cataclysmic events have been noted as the final acts of the Dawnbringers. Some of Solanis' brethren consider the sect as insane and foolish while others pray for their safety and good works.

