---
Title: Veilbound
Type: Fellowship
Directory: Lore/Fellowships/Veilbound
Category:
  - Fellowship
  - Organizations
Patron Deity: Lunessa
Planes:
  - Material
  - Ethereal
  - Astral
  - Celestial
Pantheon: Lesser_Deities
Associated_Fellowships:
  - Echoes of Lunessa
  - Moonlit Striders
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - lunessa
---

# Veilbound


Guardians of secrets and hidden truths, these followers protect knowledge that could unravel kingdoms. They serve rulers, spies, and historians alike — but never give their loyalty blindly.
[[Lunessa]]
