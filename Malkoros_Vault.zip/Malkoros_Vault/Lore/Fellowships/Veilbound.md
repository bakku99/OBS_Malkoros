---
Patron Deity: Lunessa
---

# Veilbound


Guardians of secrets and hidden truths, these followers protect knowledge that could unravel kingdoms. They serve rulers, spies, and historians alike — but never give their loyalty blindly.
[[Lunessa]]
