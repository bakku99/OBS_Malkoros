---
Patron Deity: Zephrayl
---

# Cloudchasers


Skyborn acolytes who leap between isles of wind with wings or spells. They believe the soul must fly untethered through both life and afterlife, and they map the “skylines” of all planes.
[[Zephrayl]]
