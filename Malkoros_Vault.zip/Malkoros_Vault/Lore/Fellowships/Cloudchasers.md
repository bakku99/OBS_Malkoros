---
Title: Cloudchasers
Type: Fellowship
Directory: Lore/Fellowships/Cloudchasers
Category:
  - Fellowship
  - Organizations
Patron Deity: Zephrayl
Planes:
  - Elemental
  - Air
Pantheon: Elemental_Deities
Associated_Fellowships:
  - Storm Heralds
  - The Whisperwing
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - zephrayl
---

# Cloudchasers


Skyborn acolytes who leap between isles of wind with wings or spells. They believe the soul must fly untethered through both life and afterlife, and they map the “skylines” of all planes.
[[Zephrayl]]
