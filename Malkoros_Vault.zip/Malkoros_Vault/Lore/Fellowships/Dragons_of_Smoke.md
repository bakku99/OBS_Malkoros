---
Patron Deity: Othys
---

# Dragons of Smoke


The path of Dragons bespeaks of anger and vengeance. This is the dark and dangerous face of Othys. The Dragons are assassins without compare, seeking to deliver the taste and pain of death with a swift stroke. They believe they fulfill Othys's anger and pain against those who deserve death as their only punishment. The souls taken by these killers are tied to their killer by Othys's will. The assassins then teach the soul through whisperings and deeds of why they have been killed and the blessing of their return as followers of the Devourer, for they have been chosen to be his brood. Few know of these followers, these hand-picked and trained assassins. Their numbers are few but powerful. Elves, Dwarves, Tieflings, and Men who have fallen from the light and have stony-hearts are typically chosen by Othys for this path. Never again will they serve another.
[[Othys]]
