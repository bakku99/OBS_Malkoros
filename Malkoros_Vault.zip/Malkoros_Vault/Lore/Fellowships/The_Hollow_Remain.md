---
Patron Deity: Nysthariel
---

# The Hollow Remain


Mourners who walk the lands collecting grief. They absorb and preserve the last memories of the dead, sealing them in shadowglass. Their presence is said to ease restless spirits and silence the undead.
[[Nysthariel]]
