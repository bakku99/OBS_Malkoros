---
Title: The_Hollow_Remain
Type: Fellowship
Directory: Lore/Fellowships/The_Hollow_Remain
Category:
  - Fellowship
  - Organizations
Patron Deity: Nysthariel
Planes:
  - Elemental
  - Shadow
Pantheon: Elemental_Deities
Associated_Fellowships:
  - Echobinders
  - Maskbearers
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - nysthariel
---

# The Hollow Remain


Mourners who walk the lands collecting grief. They absorb and preserve the last memories of the dead, sealing them in shadowglass. Their presence is said to ease restless spirits and silence the undead.
[[Nysthariel]]
