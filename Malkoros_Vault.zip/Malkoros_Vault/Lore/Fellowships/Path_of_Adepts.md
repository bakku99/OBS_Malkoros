---
Title: Path_of_Adepts
Type: Fellowship
Directory: Lore/Fellowships/Path_of_Adepts
Category:
  - Fellowship
  - Organizations
Patron Deity: Ineas
Planes:
  - Material
  - Ethereal
  - Astral
  - Celestial
Pantheon: Greater_Deities
Associated_Fellowships:
  - Path of Dynasty
  - Path of Beasts
  - Path of Ash
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - ineas
---

# Path of Adepts


This path seeks the ever changing power and mysteries of magic. Walkers of this path, or Magisters, are the divine counterparts to mages. The Magisters are adepts of herbs, alchemy, elements, rotes, rituals, and ancient lores yet found to create and expand the limits mages place on magic. When a Magister and a mage meet, the results can be catastrophic and illuminating for both. The Path of Adepts has strong roots in Dalpool, Pekar.
[[Ineas]]
