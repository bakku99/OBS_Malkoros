---
Patron Deity: Ineas
---

# Path of Adepts


This path seeks the ever changing power and mysteries of magic. Walkers of this path, or Magisters, are the divine counterparts to mages. The Magisters are adepts of herbs, alchemy, elements, rotes, rituals, and ancient lores yet found to create and expand the limits mages place on magic. When a Magister and a mage meet, the results can be catastrophic and illuminating for both. The Path of Adepts has strong roots in Dalpool, Pekar.
[[Ineas]]
