---
Title: Dark_Hand
Type: Fellowship
Directory: Lore/Fellowships/Dark_Hand
Category:
  - Fellowship
  - Organizations
Patron Deity: Othys
Planes:
  - Material
  - Ethereal
  - Astral
  - Celestial
Pantheon: Greater_Deities
Associated_Fellowships:
  - Attendants of the Rapture
  - Dragons of Smoke
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - othys
---

# Dark Hand


Members of the Dark Hand take a dark road of death, delivering its chill touch to those they deem worthy. These are the judges, the dividers of the way. Their methods are questionable and bent, gaining the fear and loathing of most of the pantheon and people of Malkoros. Their techniques include torture, deprevation, and bloodletting. And those that receive their dark gift are those who meet the sometimes twisted, other times coldly calculating, sense of worth. The numbers of this path grow and dwindle without any clear reason. They are found typically around the human nations, the various mines of Dramfark, and the Underdark nations.
 [Othys](Othys.md).
