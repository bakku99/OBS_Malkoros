---
Patron Deity: Pyrius
---

# The Ashen Conclave


A secretive order of efreeti and salamanders who see Pyrius not only as a god of creation, but as the rightful ruler of all elemental planes. They plan conquest in his name, though Pyrius himself seems indifferent to mortal politics.
[[Pyrius]]
