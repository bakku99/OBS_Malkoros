---
Title: The_Ashen_Conclave
Type: Fellowship
Directory: Lore/Fellowships/The_Ashen_Conclave
Category:
  - Fellowship
  - Organizations
Patron Deity: Pyrius
Planes:
  - Elemental
  - Fire
Pantheon: Elemental_Deities
Associated_Fellowships:
  - Burning Sons
  - Cinderscribes
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - pyrius
---

# The Ashen Conclave


A secretive order of efreeti and salamanders who see Pyrius not only as a god of creation, but as the rightful ruler of all elemental planes. They plan conquest in his name, though Pyrius himself seems indifferent to mortal politics.
[[Pyrius]]
