---
Patron Deity: Ulvaarak
---

# Children of Shard-Flesh


Demonic savants who sew different pieces of Ulvaarak’s will into flesh, creating warped “prophets” of madness. They do not speak — their bodies pulse with ritual screams encoded in muscle.
[[Ulvaarak]]