---
Title: Children_of_Shard-Flesh
Type: Fellowship
Directory: Lore/Fellowships/Children_of_Shard-Flesh
Category:
  - Fellowship
  - Organizations
Patron Deity: Ulvaarak
Planes:
  - Lower
  - Abyss
Pantheon: Lower_Planes_Deities
Associated_Fellowships:
  - Maws of the Thousand
  - Gorehowlers
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - ulvaarak
---

# Children of Shard-Flesh


Demonic savants who sew different pieces of Ulvaarak’s will into flesh, creating warped “prophets” of madness. They do not speak — their bodies pulse with ritual screams encoded in muscle.
[[Ulvaarak]]