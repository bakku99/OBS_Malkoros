---
Patron Deity: Hostus
---

# Dancers of the Oak


The Dancers take great joy in nature, the power and beauty of it. These followers tend to be beautiful in some way, be it of features or art. They seek to touch all of nature, to enhance its beauty and life, to heal and nuture. Each season of spring, they gather around oak trees, dancing in the moonlight and weaving ribbons of greens, golds, and pinks. If the year proves to be favorable, the ribbons blossom into flowers and vines the next morning.
[[Hostus]]
