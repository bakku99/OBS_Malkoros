---
Patron Deity: Ulvaarak
---

# Maws of the Thousand


Cults of cannibalistic prophets who believe each act of devouring brings them closer to being “swallowed back” into the Maw.
[[Ulvaarak]]
