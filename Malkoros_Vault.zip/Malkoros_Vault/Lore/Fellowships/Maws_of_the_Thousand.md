---
Title: Maws_of_the_Thousand
Type: Fellowship
Directory: Lore/Fellowships/Maws_of_the_Thousand
Category:
  - Fellowship
  - Organizations
Patron Deity: Ulvaarak
Planes:
  - Lower
  - Abyss
Pantheon: Lower_Planes_Deities
Associated_Fellowships:
  - Children of Shard-Flesh
  - Gorehowlers
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - ulvaarak
---

# Maws of the Thousand


Cults of cannibalistic prophets who believe each act of devouring brings them closer to being “swallowed back” into the Maw.
[[Ulvaarak]]
