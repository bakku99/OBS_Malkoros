---
Title: Children_of_the_Second_Tongue
Type: Fellowship
Directory: Lore/Fellowships/Children_of_the_Second_Tongue
Category:
  - Fellowship
  - Organizations
Patron Deity: Xexas
Planes:
  - Material
  - Ethereal
  - Astral
  - Celestial
Pantheon: Lesser_Deities
Associated_Fellowships:
  - Bladed Veil
  - Lachrymists
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - xexas
---

# Children of the Second Tongue


Diplomats, scribes, and spies who speak lies as if they were prophecy. Their oath: “We speak, and the world bends.”
[[Xexas]]
