---
Patron Deity: Xexas
---

# Children of the Second Tongue


Diplomats, scribes, and spies who speak lies as if they were prophecy. Their oath: “We speak, and the world bends.”
[[Xexas]]
