---
Patron Deity: Atotz
---

# Spinning Stars


These followers seek to become bright and shining stars of Atotz. The largest group of worshippers, the Stars walk the world seeking to understand the loving and fickle nature that is fortune and chance. Their views are the basis of Atotz's teachings. One of the largest of Atotz's churches run by the Stars is a gambling house and temple in Taavine, Lumella.
[[Atotz]]
