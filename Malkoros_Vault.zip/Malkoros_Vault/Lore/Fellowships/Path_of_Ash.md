---
Title: Path_of_Ash
Type: Fellowship
Directory: Lore/Fellowships/Path_of_Ash
Category:
  - Fellowship
  - Organizations
Patron Deity: Ineas
Planes:
  - Material
  - Ethereal
  - Astral
  - Celestial
Pantheon: Greater_Deities
Associated_Fellowships:
  - Path of Adepts
  - Path of Dynasty
  - Path of Beasts
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - ineas
---

# Path of Ash


This path seeks to understand the power and terror of the dead, undead, the afterlife, demons, and devils. Few walkers of the path, or the Burdens, ever successfully gain great knowledge of this path before dying terrible deaths. However, their knowledge is the greatest when one needs to understand the path of evil. Many nobles of Lumellan kingdoms have sought the Burdens when warring with each other. These followers hide themselves in the Ruins of Thrinacia of Caltorra.
[[Ineas]]
