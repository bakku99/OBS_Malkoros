---
Title: Tidecallers
Type: Fellowship
Directory: Lore/Fellowships/Tidecallers
Category:
  - Fellowship
  - Organizations
Patron Deity: Eirsyr
Planes:
  - Elemental
  - Water
Pantheon: Elemental_Deities
Associated_Fellowships:
  - Glacient Wardens
  - Sisters of Stillwater
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - eirsyr
---

# Tidecallers


Sorcerers and prophets who read the flow of currents and weather to divine the fates of mortals. They move with the tides of fate, and their word is often followed by floods or salvation.
[[Eirsyr]]
