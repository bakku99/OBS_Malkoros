---
Patron Deity: Eirsyr
---

# Tidecallers


Sorcerers and prophets who read the flow of currents and weather to divine the fates of mortals. They move with the tides of fate, and their word is often followed by floods or salvation.
[[Eirsyr]]
