---
Title: The_Chainforged
Type: Fellowship
Directory: Lore/Fellowships/The_Chainforged
Category:
  - Fellowship
  - Organizations
Patron Deity: Azhadûn
Planes:
  - Lower
  - Nine Hells
Pantheon: Lower_Planes_Deities
Associated_Fellowships:
  - Accorded Eyes
  - The Order of the Final Clause
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - Azhadûn
---

# The Chainforged


Devils of the lower circles who serve as enforcers of infernal law. Their chains are sentient, wrapping around liars and oathbreakers without command.
[[Azhadûn]]
