---
Patron Deity: Azhadûn
---

# The Chainforged


Devils of the lower circles who serve as enforcers of infernal law. Their chains are sentient, wrapping around liars and oathbreakers without command.
[[Azhadûn]]
