---
Patron Deity: Pyrius
---

# Burning Sons

**Devoted warriors and monks who burn away impurity through sacred flame. They practice immolation rituals and view pain as the passage to transcendence. Often seen leading purging missions against planar invaders or corruption.**
[[Pyrius]]