---
Title: Burning_Sons
Type: Fellowship
Directory: Lore/Fellowships/Burning_Sons
Category:
  - Fellowship
  - Organizations
Patron Deity: Pyrius
Planes:
  - Elemental
  - Fire
Pantheon: Elemental_Deities
Associated_Fellowships:
  - Cinderscribes
  - The Ashen Conclave
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - fire
  - pyrius
---

# Burning Sons

**Devoted warriors and monks who burn away impurity through sacred flame. They practice immolation rituals and view pain as the passage to transcendence. Often seen leading purging missions against planar invaders or corruption.**
[[Pyrius]]