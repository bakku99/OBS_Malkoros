---
Title: Warders_of_the_Gate
Type: Fellowship
Directory: Lore/Fellowships/Warders_of_the_Gate
Category:
  - Fellowship
  - Organizations
Patron Deity: Therassor
Planes:
  - Material
  - Ethereal
  - Astral
  - Celestial
Pantheon: Greater_Deities
Associated_Fellowships:
  - Governors of Battle
  - Ghardankuldar (Stalwart Warriors)
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - therassor
---

# Warders of the Gate


The Warders are warrior-clerics who defend the line against darkness and evil. Strong of arm and heart, they face the oncoming darkness wrought in the world by man and beast. Their numbers are found among the greatest of cities and nations and the most quiet and peaceful of villages. This is the largest of Therassor's fellowships with many city guards, warriors, ethical mercenaries, and lords turning to his worship.
[[Therassor]]
