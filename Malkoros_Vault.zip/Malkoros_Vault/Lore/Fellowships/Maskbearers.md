---
Title: Maskbearers
Type: Fellowship
Directory: Lore/Fellowships/Maskbearers
Category:
  - Fellowship
  - Organizations
Patron Deity: Nysthariel
Planes:
  - Elemental
  - Shadow
Pantheon: Elemental_Deities
Associated_Fellowships:
  - Echobinders
  - The Hollow Remain
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - nysthariel
---

# Maskbearers


Monks and whisperers who wear emotionless masks as symbols of truth withheld. They record every lie they hear and offer those records to Nysthariel in ink made from their own blood.
[[Nysthariel]]
