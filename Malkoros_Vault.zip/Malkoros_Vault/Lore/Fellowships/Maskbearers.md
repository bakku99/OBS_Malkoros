---
Patron Deity: Nysthariel
---

# Maskbearers


Monks and whisperers who wear emotionless masks as symbols of truth withheld. They record every lie they hear and offer those records to Nysthariel in ink made from their own blood.
[[Nysthariel]]
