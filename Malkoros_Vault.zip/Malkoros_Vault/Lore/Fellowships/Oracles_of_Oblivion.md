---
Title: Oracles_of_Oblivion
Type: Fellowship
Directory: Lore/Fellowships/Oracles_of_Oblivion
Category:
  - Fellowship
  - Organizations
Patron Deity: Uztix
Planes:
  - Material
  - Ethereal
  - Astral
  - Celestial
Pantheon: Greater_Deities
Associated_Fellowships:
  - Riders of the Dark Tide
  - Walkers of the Serpentine Labyrinth
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - uztix
---

# Oracles of Oblivion


The Oracles watch the cosmos and the hearts of people for a chance to corrupt. With darkened visions and magics, they delve deeply into the world to find its hidden truths to taint and twist for their own means. And once they have delivered their seed, they lie in wait and help it grow. Many of Uztix's followers take to this path.
[[Uztix]]
