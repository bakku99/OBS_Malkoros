---
Patron Deity: Uztix
---

# Oracles of Oblivion


The Oracles watch the cosmos and the hearts of people for a chance to corrupt. With darkened visions and magics, they delve deeply into the world to find its hidden truths to taint and twist for their own means. And once they have delivered their seed, they lie in wait and help it grow. Many of Uztix's followers take to this path.
[[Uztix]]
