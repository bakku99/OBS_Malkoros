---
Title: Keepers_of_the_Brand
Type: Fellowship
Directory: Lore/Fellowships/Keepers_of_the_Brand
Category:
  - Fellowship
  - Organizations
Patron Deity: Vaelreth
Planes:
  - Material
  - Ethereal
  - Astral
  - Celestial
Pantheon: Lesser_Deities
Associated_Fellowships:
  - Ashen Circle
  - Scorchbearers
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - vaelreth
---

# Keepers of the Brand


Once broken souls, the Keepers mark themselves with Vaelreth's sigil as a sign of eternal oath. They protect the weak and uphold the law where law has crumbled. They rarely kill — but their punishments are swift and absolute.
[[Vaelreth]]
