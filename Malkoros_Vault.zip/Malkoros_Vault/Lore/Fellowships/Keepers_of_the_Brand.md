---
Patron Deity: Vaelreth
---

# Keepers of the Brand


Once broken souls, the Keepers mark themselves with Vaelreth's sigil as a sign of eternal oath. They protect the weak and uphold the law where law has crumbled. They rarely kill — but their punishments are swift and absolute.
[[Vaelreth]]
