---
Patron Deity: Myrradyn
---

# Fractaline Circle


A secretive cabal of mages who willingly break their own minds to glimpse higher arcane understanding. They function as collective beings — fractured but unified — wielding unstable magic with unmatched creativity.
[[Myrradyn]]
