---
Title: Fractaline_Circle
Type: Fellowship
Directory: Lore/Fellowships/Fractaline_Circle
Category:
  - Fellowship
  - Organizations
Patron Deity: Myrradyn
Planes:
  - Elemental
  - Arcane
Pantheon: Elemental_Deities
Associated_Fellowships:
  - Inkborn Choir
  - The Loomwalkers
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - myrradyn
---

# Fractaline Circle


A secretive cabal of mages who willingly break their own minds to glimpse higher arcane understanding. They function as collective beings — fractured but unified — wielding unstable magic with unmatched creativity.
[[Myrradyn]]
