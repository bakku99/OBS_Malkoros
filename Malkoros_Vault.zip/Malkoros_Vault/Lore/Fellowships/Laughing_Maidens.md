---
Patron Deity: Atotz
---

# Laughing Maidens


This all-female group travels the world teaching newcomers to the open road what it trully means to be an adventurer. Many of these women began as serving wenches and daughters of great warriors that did not understand why only men could adventure. Each of them left the safety of their homes and found a common following of other women who loved the freedom of the road. Members of this group meet in taverns throughout Malkoros, with the largest congregation forming in The Glades.
[[Atotz]]
