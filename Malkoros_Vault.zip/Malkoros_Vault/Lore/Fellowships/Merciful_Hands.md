---
Patron Deity: Vandryl
---

# Merciful Hands


Wandering physicians who heal the living and raise the dead alike. Their symbol is feared by many, yet they are often welcomed by those too desperate to care about the cost.
[[Vandryl]]
