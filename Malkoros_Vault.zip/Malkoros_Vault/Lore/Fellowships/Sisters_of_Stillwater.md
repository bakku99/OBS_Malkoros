---
Title: Sisters_of_Stillwater
Type: Fellowship
Directory: Lore/Fellowships/Sisters_of_Stillwater
Category:
  - Fellowship
  - Organizations
Patron Deity: Eirsyr
Planes:
  - Elemental
  - Water
Pantheon: Elemental_Deities
Associated_Fellowships:
  - Glacient Wardens
  - Tidecallers
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - eirsyr
---

# Sisters of Stillwater


A reclusive sect of priestesses, oracles, and memory-keepers who bathe the dying in sacred pools to preserve their final thoughts. They believe that in freezing memory, the soul is granted peace.
[[Eirsyr]]
