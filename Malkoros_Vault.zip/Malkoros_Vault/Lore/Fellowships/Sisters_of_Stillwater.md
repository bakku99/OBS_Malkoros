---
Patron Deity: Eirsyr
---

# Sisters of Stillwater


A reclusive sect of priestesses, oracles, and memory-keepers who bathe the dying in sacred pools to preserve their final thoughts. They believe that in freezing memory, the soul is granted peace.
[[Eirsyr]]
