---
Patron Deity: Lunessa
---

# Moonlit Striders


Wandering protectors of the night, the Striders help travelers find their way by moonlight and stalk creatures that hunt from the shadows. They are silent sentinels, ever watching.
[[Lunessa]]
