---
Title: Moonlit_Striders
Type: Fellowship
Directory: Lore/Fellowships/Moonlit_Striders
Category:
  - Fellowship
  - Organizations
Patron Deity: Lunessa
Planes:
  - Material
  - Ethereal
  - Astral
  - Celestial
Pantheon: Lesser_Deities
Associated_Fellowships:
  - Echoes of Lunessa
  - Veilbound
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - lunessa
---

# Moonlit Striders


Wandering protectors of the night, the Striders help travelers find their way by moonlight and stalk creatures that hunt from the shadows. They are silent sentinels, ever watching.
[[Lunessa]]
