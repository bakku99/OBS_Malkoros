---
Title: Glacient_Wardens
Type: Fellowship
Directory: Lore/Fellowships/Glacient_Wardens
Category:
  - Fellowship
  - Organizations
Patron Deity: Eirsyr
Planes:
  - Elemental
  - Water
Pantheon: Elemental_Deities
Associated_Fellowships:
  - Sisters of Stillwater
  - Tidecallers
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - eirsyr
---

# Glacient Wardens


Guardians of knowledge, relics, and prisoners sealed away for all time. They believe some things are too dangerous to destroy — and must instead be forgotten beneath ice.
[[Eirsyr]]
