---
Patron Deity: Eirsyr
---

# Glacient Wardens


Guardians of knowledge, relics, and prisoners sealed away for all time. They believe some things are too dangerous to destroy — and must instead be forgotten beneath ice.
[[Eirsyr]]
