---
Title: The_Deepbound
Type: Fellowship
Directory: Lore/Fellowships/The_Deepbound
Category:
  - Fellowship
  - Organizations
Patron Deity: Thavax
Planes:
  - Elemental
  - Earth
Pantheon: Elemental_Deities
Associated_Fellowships:
  - Stonewatchers
  - Verdant Core
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - thavax
---

# The Deepbound


Architects and geomancers who shape not just stone, but the memory of the land itself. They build temples, vaults, and tombs meant to last for millennia.
[[Thavax]]
