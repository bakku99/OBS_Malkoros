---
Patron Deity: Thavax
---

# The Deepbound


Architects and geomancers who shape not just stone, but the memory of the land itself. They build temples, vaults, and tombs meant to last for millennia.
[[Thavax]]
