---
Title: Scorchbearers
Type: Fellowship
Directory: Lore/Fellowships/Scorchbearers
Category:
  - Fellowship
  - Organizations
Patron Deity: Vaelreth
Planes:
  - Material
  - Ethereal
  - Astral
  - Celestial
Pantheon: Lesser_Deities
Associated_Fellowships:
  - Ashen Circle
  - Keepers of the Brand
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - vaelreth
---

# Scorchbearers


These avengers carry the Flame of Vaelreth into the heart of darkness. They hunt slavers, tyrants, and corrupt nobles, delivering divine judgment without mercy. Their presence is often feared even by the righteous.
[[Vaelreth]]
