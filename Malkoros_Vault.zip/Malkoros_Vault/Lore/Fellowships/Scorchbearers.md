---
Patron Deity: Vaelreth
---

# Scorchbearers


These avengers carry the Flame of Vaelreth into the heart of darkness. They hunt slavers, tyrants, and corrupt nobles, delivering divine judgment without mercy. Their presence is often feared even by the righteous.
[[Vaelreth]]
