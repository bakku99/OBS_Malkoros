---
Patron Deity: Kaelis
---

# Emberwilds


Nomadic celebrants who bring songs, wine, and riot to every village they pass. They defy curfews, crash ceremonies, and leave behind festivals that last days. Some call them blessings. Others call them plagues.
[[Kaelis]]
