---
Title: Emberwilds
Type: Fellowship
Directory: Lore/Fellowships/Emberwilds
Category:
  - Fellowship
  - Organizations
Patron Deity: Kaelis
Planes:
  - Material
  - Ethereal
  - Astral
  - Celestial
Pantheon: Lesser_Deities
Associated_Fellowships:
  - Stagblood Pact
  - The Chainbreakers
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - kaelis
---

# Emberwilds


Nomadic celebrants who bring songs, wine, and riot to every village they pass. They defy curfews, crash ceremonies, and leave behind festivals that last days. Some call them blessings. Others call them plagues.
[[Kaelis]]
