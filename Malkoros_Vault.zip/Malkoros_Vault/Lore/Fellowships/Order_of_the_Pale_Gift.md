---
Patron Deity: Vandryl
---

# Order of the Pale Gift


Caretakers of the dying who offer the choice of eternal, peaceful undeath to those in agony. Their temples double as sanctuaries and mausoleums.
[[Vandryl]]
