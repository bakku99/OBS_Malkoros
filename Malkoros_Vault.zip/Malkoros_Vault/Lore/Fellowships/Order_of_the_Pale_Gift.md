---
Title: Order_of_the_Pale_Gift
Type: Fellowship
Directory: Lore/Fellowships/Order_of_the_Pale_Gift
Category:
  - Fellowship
  - Organizations
Patron Deity: Vandryl
Planes:
  - Material
  - Ethereal
  - Astral
  - Celestial
Pantheon: Lesser_Deities
Associated_Fellowships:
  - Duskborn Choir
  - Merciful Hands
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - vandryl
---

# Order of the Pale Gift


Caretakers of the dying who offer the choice of eternal, peaceful undeath to those in agony. Their temples double as sanctuaries and mausoleums.
[[Vandryl]]
