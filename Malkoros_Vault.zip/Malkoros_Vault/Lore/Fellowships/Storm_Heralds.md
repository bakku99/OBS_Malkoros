---
Patron Deity: Zephrayl
---

# Storm Heralds


Oracles and battle-priests who summon tempests in Zephrayl’s name. They bring change to stagnant lands, justice to tyrants, or madness to the overly ordered.
[[Zephrayl]]
