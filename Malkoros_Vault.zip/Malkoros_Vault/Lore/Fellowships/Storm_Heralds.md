---
Title: Storm_Heralds
Type: Fellowship
Directory: Lore/Fellowships/Storm_Heralds
Category:
  - Fellowship
  - Organizations
Patron Deity: Zephrayl
Planes:
  - Elemental
  - Air
Pantheon: Elemental_Deities
Associated_Fellowships:
  - Cloudchasers
  - The Whisperwing
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - zephrayl
---

# Storm Heralds


Oracles and battle-priests who summon tempests in Zephrayl’s name. They bring change to stagnant lands, justice to tyrants, or madness to the overly ordered.
[[Zephrayl]]
