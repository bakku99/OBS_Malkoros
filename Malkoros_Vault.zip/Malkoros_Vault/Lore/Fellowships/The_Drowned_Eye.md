---
Patron Deity: Tahrun
---

# The Drowned Eye


A cult-like sect that intentionally fractures the mind to "see more clearly." Through ritual madness, fasting, and chanting, they believe they can speak with Tahrun directly. Few who enter their ranks ever return unchanged.
[[Tahrun]]
