---
Title: The_Drowned_Eye
Type: Fellowship
Directory: Lore/Fellowships/The_Drowned_Eye
Category:
  - Fellowship
  - Organizations
Patron Deity: Tahrun
Planes:
  - Material
  - Ethereal
  - Astral
  - Celestial
Pantheon: Lesser_Deities
Associated_Fellowships:
  - Circle of the Folded Veil
  - The Whispering Quill
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - tahrun
---

# The Drowned Eye


A cult-like sect that intentionally fractures the mind to "see more clearly." Through ritual madness, fasting, and chanting, they believe they can speak with Tahrun directly. Few who enter their ranks ever return unchanged.
[[Tahrun]]
