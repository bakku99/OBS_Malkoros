---
Patron Deity: Zephrayl
---

# The Whisperwing


A secretive fellowship of spies, dreamwalkers, and elemental windshapers who pass unseen across borders, listening for divine truths carried on the breeze. They rarely speak — but their messages echo for miles.
[[Zephrayl]]
