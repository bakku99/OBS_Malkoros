---
Title: The_Whisperwing
Type: Fellowship
Directory: Lore/Fellowships/The_Whisperwing
Category:
  - Fellowship
  - Organizations
Patron Deity: Zephrayl
Planes:
  - Elemental
  - Air
Pantheon: Elemental_Deities
Associated_Fellowships:
  - Cloudchasers
  - Storm Heralds
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - zephrayl
---

# The Whisperwing


A secretive fellowship of spies, dreamwalkers, and elemental windshapers who pass unseen across borders, listening for divine truths carried on the breeze. They rarely speak — but their messages echo for miles.
[[Zephrayl]]
