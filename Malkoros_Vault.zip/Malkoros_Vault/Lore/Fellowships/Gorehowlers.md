---
Patron Deity: Ulvaarak
---

# Gorehowlers


Screaming berserkers and demonic warlords who tear open the veil between planes through sheer violence. They fight not for conquest, but to ruin the very concept of victory.
[[Ulvaarak]]
