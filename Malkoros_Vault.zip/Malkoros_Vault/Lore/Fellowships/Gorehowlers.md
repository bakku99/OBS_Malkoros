---
Title: Gorehowlers
Type: Fellowship
Directory: Lore/Fellowships/Gorehowlers
Category:
  - Fellowship
  - Organizations
Patron Deity: Ulvaarak
Planes:
  - Lower
  - Abyss
Pantheon: Lower_Planes_Deities
Associated_Fellowships:
  - Children of Shard-Flesh
  - Maws of the Thousand
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - ulvaarak
---

# Gorehowlers


Screaming berserkers and demonic warlords who tear open the veil between planes through sheer violence. They fight not for conquest, but to ruin the very concept of victory.
[[Ulvaarak]]
