---
Title: Inkborn_Choir
Type: Fellowship
Directory: Lore/Fellowships/Inkborn_Choir
Category:
  - Fellowship
  - Organizations
Patron Deity: Myrradyn
Planes:
  - Elemental
  - Arcane
Pantheon: Elemental_Deities
Associated_Fellowships:
  - Fractaline Circle
  - The Loomwalkers
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - myrradyn
---

# Inkborn Choir


Transmuted spell-scrolls given sentience, along with mortal archivists who believe writing is the purest form of worship. Their prayers are written, never spoken, and sometimes change retroactively.
[[Myrradyn]]
