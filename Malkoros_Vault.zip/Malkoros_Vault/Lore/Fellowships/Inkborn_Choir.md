---
Patron Deity: Myrradyn
---

# Inkborn Choir


Transmuted spell-scrolls given sentience, along with mortal archivists who believe writing is the purest form of worship. Their prayers are written, never spoken, and sometimes change retroactively.
[[Myrradyn]]
