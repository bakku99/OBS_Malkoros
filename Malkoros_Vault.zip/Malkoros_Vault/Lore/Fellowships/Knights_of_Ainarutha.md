---
Title: Knights_of_Ainarutha
Type: Fellowship
Directory: Lore/Fellowships/Knights_of_Ainarutha
Category:
  - Fellowship
  - Organizations
Patron Deity: Solanis
Planes:
  - Material
  - Ethereal
  - Astral
  - Celestial
Pantheon: Greater_Deities
Associated_Fellowships:
  - Dawnbringers
  - Eyes of the Blazing Sun
  - Society of Luminaries
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - solanis
---

# Knights of Ainarutha


These knights are powerful clerics who seek to end the tyranny and evil of the dark and undead. The Aina'rutha, or Holy Anger, was founded by two clerics: Gilmandrion, priest of Solanis, and Amiolia, priestess of Solanis. The two met in Vanulum to answer the aid of the council under attack by dark forces. Together, they worked to banish the darkness and heal the injured. After the terror passed, the two spoke with others and soon a following was formed. Members typically are elven and human, though some dwarves have come to the call.
[[Solanis]]
