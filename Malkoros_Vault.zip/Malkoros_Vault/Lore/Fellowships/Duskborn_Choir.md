---
Patron Deity: Vandryl
---

# Duskborn Choir


Whisper-singers who lull the dying into dreams of undeath. Their chants are said to anchor souls to flesh long enough for necromancers to bind them anew.
[[Vandryl]]
