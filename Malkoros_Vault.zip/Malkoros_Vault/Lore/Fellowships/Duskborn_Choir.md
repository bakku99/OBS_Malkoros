---
Title: Duskborn_Choir
Type: Fellowship
Directory: Lore/Fellowships/Duskborn_Choir
Category:
  - Fellowship
  - Organizations
Patron Deity: Vandryl
Planes:
  - Material
  - Ethereal
  - Astral
  - Celestial
Pantheon: Lesser_Deities
Associated_Fellowships:
  - Order of the Pale Gift
  - Merciful Hands
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - vandryl
---

# Duskborn Choir


Whisper-singers who lull the dying into dreams of undeath. Their chants are said to anchor souls to flesh long enough for necromancers to bind them anew.
[[Vandryl]]
