---
Patron Deity: Nysthariel
---

# Echobinders


Sorcerers, assassins, and voidmages who bind sound, reflection, and memory to their will. They believe that all stories are shadows cast by greater truths — and that cutting the shadow can reshape the source.
[[Nysthariel]]
