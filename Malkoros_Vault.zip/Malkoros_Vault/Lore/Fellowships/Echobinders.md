---
Title: Echobinders
Type: Fellowship
Directory: Lore/Fellowships/Echobinders
Category:
  - Fellowship
  - Organizations
Patron Deity: Nysthariel
Planes:
  - Elemental
  - Shadow
Pantheon: Elemental_Deities
Associated_Fellowships:
  - Maskbearers
  - The Hollow Remain
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - nysthariel
---

# Echobinders


Sorcerers, assassins, and voidmages who bind sound, reflection, and memory to their will. They believe that all stories are shadows cast by greater truths — and that cutting the shadow can reshape the source.
[[Nysthariel]]
