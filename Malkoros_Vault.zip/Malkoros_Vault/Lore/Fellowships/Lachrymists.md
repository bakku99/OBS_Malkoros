---
Title: Lachrymists
Type: Fellowship
Directory: Lore/Fellowships/Lachrymists
Category:
  - Fellowship
  - Organizations
Patron Deity: Xexas
Planes:
  - Material
  - Ethereal
  - Astral
  - Celestial
Pantheon: Lesser_Deities
Associated_Fellowships:
  - Bladed Veil
  - Children of the Second Tongue
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - xexas
---

# Lachrymists


Poison-makers and torturers who believe suffering is art. Their toxins don’t just kill — they reveal. To be Lachrymisted is to confess your soul.
[[Xexas]]
