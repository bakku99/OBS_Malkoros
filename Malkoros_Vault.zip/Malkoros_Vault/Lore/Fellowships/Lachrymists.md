---
Patron Deity: Xexas
---

# Lachrymists


Poison-makers and torturers who believe suffering is art. Their toxins don’t just kill — they reveal. To be Lachrymisted is to confess your soul.
[[Xexas]]
