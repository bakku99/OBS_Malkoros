---
Title: The_Whispering_Quill
Type: Fellowship
Directory: Lore/Fellowships/The_Whispering_Quill
Category:
  - Fellowship
  - Organizations
Patron Deity: Tahrun
Planes:
  - Material
  - Ethereal
  - Astral
  - Celestial
Pantheon: Lesser_Deities
Associated_Fellowships:
  - Circle of the Folded Veil
  - The Drowned Eye
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - tahrun
---

# The Whispering Quill


Wandering scribes who record visions, dreams, and unconscious ramblings in sacred scrolls. Their prophecies are often indecipherable — until they come true.
[[Tahrun]]
