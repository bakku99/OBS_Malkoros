---
Patron Deity: Tahrun
---

# The Whispering Quill


Wandering scribes who record visions, dreams, and unconscious ramblings in sacred scrolls. Their prophecies are often indecipherable — until they come true.
[[Tahrun]]
