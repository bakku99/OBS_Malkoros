---
Patron Deity: Thavax
---

# Stonewatchers


Vigilant sentries who never leave their post unless the world demands it. Their oaths are eternal, their discipline unmatched. Many stand guard over ancient seals, buried vaults, or sacred gates.
[[Thavax]]
