---
Title: Stonewatchers
Type: Fellowship
Directory: Lore/Fellowships/Stonewatchers
Category:
  - Fellowship
  - Organizations
Patron Deity: Thavax
Planes:
  - Elemental
  - Earth
Pantheon: Elemental_Deities
Associated_Fellowships:
  - The Deepbound
  - Verdant Core
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - thavax
---

# Stonewatchers


Vigilant sentries who never leave their post unless the world demands it. Their oaths are eternal, their discipline unmatched. Many stand guard over ancient seals, buried vaults, or sacred gates.
[[Thavax]]
