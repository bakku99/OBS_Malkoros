---
Title: The_Order_of_the_Final_Clause
Type: Fellowship
Directory: Lore/Fellowships/The_Order_of_the_Final_Clause
Category:
  - Fellowship
  - Organizations
Patron Deity: Azhadûn
Planes:
  - Lower
  - Nine Hells
Pantheon: Elemental_Deities
Associated_Fellowships:
  - Accorded Eyes
  - The Chainforged
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - Azhadûn
---

# The Order of the Final Clause


Judges and arch-devils who believe every soul will eventually serve Azhadûn — willingly or not. They offer terms of salvation, knowing that damnation lies in the fine print.
[[Azhadûn]]
