---
Patron Deity: Azhadûn
---

# The Order of the Final Clause


Judges and arch-devils who believe every soul will eventually serve Azhadûn — willingly or not. They offer terms of salvation, knowing that damnation lies in the fine print.
[[Azhadûn]]
