---
Title: Echoes_of_Lunessa
Type: Fellowship
Directory: Lore/Fellowships/Echoes_of_Lunessa
Category:
  - Fellowship
  - Organizations
Patron Deity: Lunessa
Planes:
  - Material
  - Ethereal
  - Astral
  - Celestial
Pantheon: Lesser_Deities
Associated_Fellowships:
  - Moonlit Striders
  - Veilbound
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - lunessa
---

# Echoes of Lunessa


A cryptic sect that believes the moon itself is a sentient entity beyond Lunessa — that she is merely its chosen voice. Their rituals and dreams are filled with whispers from the far beyond.
[[Lunessa]]
