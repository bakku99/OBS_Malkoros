---
Patron Deity: Lunessa
---

# Echoes of Lunessa


A cryptic sect that believes the moon itself is a sentient entity beyond Lunessa — that she is merely its chosen voice. Their rituals and dreams are filled with whispers from the far beyond.
[[Lunessa]]
