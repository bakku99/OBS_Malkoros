---
Patron Deity: Solanis
---

# Society of Luminaries


The Society seeks to understand the darkness and light in the world. These loremasters maintain incredible libraries of knowledge regarding the cosmos, the struggles of man against demons, and the enlightenment of angels. The Society includes a wide range of tradesmen and artisans such as bookbinders, painters, and singers. Some remain in seclusion in the churches of the Eyes, documenting their words and copying the words of Solanis for others. Other members travel the world singing of the tales of Solanis and the writers. If ever a warrior needed to understand how to defeat darkness, it is said this Society either knows or can get the information. This fellowship binds the various sects of Solanis.
[[Solanis]]
