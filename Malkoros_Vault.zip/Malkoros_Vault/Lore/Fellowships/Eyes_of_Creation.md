---
Patron Deity: Hostus
---

# Eyes of Creation


The Eyes watch and protect all of nature. They can be found within all environments from urban cities to desolate plains. They see beauty and pain in all settings of nature. Through their patient work, they seek to aid life in those areas, to help it survive and thrive against the dangers of encroaching man or the changes of time.
[[Hostus]]
