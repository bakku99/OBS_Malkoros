---
Title: The_Unforgotten
Type: Fellowship
Directory: Lore/Fellowships/The_Unforgotten
Category:
  - Fellowship
  - Organizations
Patron Deity: Seramara
Planes:
  - Material
  - Ethereal
  - Astral
  - Celestial
Pantheon: Elemental_Deities
Associated_Fellowships:
  - Order of the Crimson Veil
  - Seramara’s Thorn
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - seramara
---

# The Unforgotten


Wandering lorekeepers who record lost histories, loves, and final words. They carve names and stories into stone tablets and starlit shrines, ensuring no soul is truly forgotten.
[[Seramara]]
