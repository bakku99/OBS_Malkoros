---
Patron Deity: Seramara
---

# The Unforgotten


Wandering lorekeepers who record lost histories, loves, and final words. They carve names and stories into stone tablets and starlit shrines, ensuring no soul is truly forgotten.
[[Seramara]]
