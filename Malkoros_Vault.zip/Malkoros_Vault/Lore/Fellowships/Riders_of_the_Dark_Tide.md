---
Title: Riders_of_the_Dark_Tide
Type: Fellowship
Directory: Lore/Fellowships/Riders_of_the_Dark_Tide
Category:
  - Fellowship
  - Organizations
Patron Deity: Uztix
Planes:
  - Material
  - Ethereal
  - Astral
  - Celestial
Pantheon: Greater_Deities
Associated_Fellowships:
  - Oracles of Oblivion
  - Walkers of the Serpentine Labyrinth
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - uztix
---

# Riders of the Dark Tide


The Riders are a terrible force of darkness and terror. They gather the minions of the dead and demonic to their banner to war against the warriors of light. Many in this legion become unholy powers, including vampires, shades, and death lords. They are known for their undead mounts with eyes of purple flame. Only the most powerful and unbalanced of her legions enter this path, for it chains their souls to the Dark Enchantress.
[[Uztix]]
