---
Title: Witchlings_of_the_Night
Type: Fellowship
Directory: Lore/Fellowships/Witchlings_of_the_Night
Category:
  - Fellowship
  - Organizations
Patron Deity: Hostus
Planes:
  - Material
  - Ethereal
  - Astral
  - Celestial
Pantheon: Greater_Deities
Associated_Fellowships:
  - Dancers of the Oak
  - Eyes of Creation
tags:
  - fellowship
  - fellowships
  - organization
  - organizations
  - hostus
---

# Witchlings of the Night


The Witchlings are a group that the followers of Hostus wish they could forget. When Hostus tasted Othys's tongue and blood, a dark seed of anger and treachery blossomed in the lord of nature. When he spat forth that tongue and seed into the earth, fires erupted and birthed a child of dark nature. This child gathered followers of Othys, who believe nature is dangerous, beautiful, and deadly. To this day, this small and secretive sect works to destroy all creations of civilization, and then replace them with their ideal of nature.
[[Hostus]]
