# Player Characters

## Lillith Deeprot
See also: [[Lillith Deeprot]]
- Species: Variant-Human
- Level: 10
- Class: Wizard (Necromancy) - Level 10
- Alignment: Chaotic Neutral
- Patron deity: Othys, God of Death
- Motives: Seek out the Books of Othys, find her father, prove herself to Othys

## Erci Tinkerton
See also: [[Erci Tinkerton]]
- Species: Rock Gnome
- Level: 10
- Class: Artificer (Armorer) - Level 5, Fighter (Rune Knight) - Level 5
- Alignment: Chaotic Neutral
- Patron deity: Hostus, God of Nature
- Motives: Create new inventions to awe all of Malkoros, help his rat companion, Tucket, return to his human form, help Lillith find the Books of Othys, find out what happened to the Artificers of Malkoros

## Varis Galanodel
See also: [[Varis Galanodel]]
- Species: Drow
- Level: 10
- Class: Ranger (Gloomstalker) - Level 5, Fighter (Battlemaster) - Level 4, Rogue - Level 1
- Alignment: Lawful Good
- Patron deity: Solanis, God of Light and Life
- Motives: Find work as a guide for scholars, learn the surface world environment, discover his true origins in the Underdark, serve Solanis 

## Sir Roland Ogletree
See also: [[Sir Roland Ogletree]]
- Species: Variant-Human
- Level: 10
- Class: Warlock (Pact of the Blade) - Level 5, Paladin (Oath of the Crown) - Level 5
- Alignment: Lawful Neutral
- Patron deity: Atotz, Goddess of Luck
- Secrets: Is a Werewolf Lycanthrope
- Motives: Serve his friends as a loyal protector and help those in need, as long as serves Lady Luck and his personal tenets. Wants to find out the origins of Lycanthropy in Malkoros. Unsure if he wants his curse removed or not.

