# Varis Galanodel
See also: [[Varis Galanodel]]
- Species: Drow
- Level: 10
- Class: Ranger (Gloomstalker) - Level 5, Fighter (Battlemaster) - Level 4, Rogue - Level 1
- Alignment: Lawful Good
- Patron deity: Solanis, God of Light and Life
- Motives: Find work as a guide for scholars, learn the surface world environment, discover his true origins in the Underdark, serve Solanis 

## Backstory
"Varis is 85 years old, He is from a small Caravan of refugees that left the Underdark City of Unbark 45 years ago. The Refuges have now formed a small village on the surface. He was formally trained from the Unbark battle academy to fight and to hunt in the wilderness of the underdark. While out on patrol with his classmates in the academy a rogue drider from a renegade house out of the favor of Lolth the Spider Queen killed his platoon. With Varis narrowly escaping with his life, he has studied various monstrosities so he can always be prepared and seeks to hunt and kill them to rid the world of evil. Since his time on the surface he is learning to adapt to the blinding rays of the surface world sun and its high peaked mountains and lush forest. The surface drow are still hated as traitors and hunted by the underdwelling drow of Raenbarad. Varis now makes a living serving as a guide to adventurers and scholars looking to explore the underdark and the underground ecosystem. He is currently traveling and looking for work and adventure, seeing as for some reason scholars have become scarce and afraid to travel to the underdark. He has joined up with a ragtag group of adventures to travel the surface with and reach the city of Arman."