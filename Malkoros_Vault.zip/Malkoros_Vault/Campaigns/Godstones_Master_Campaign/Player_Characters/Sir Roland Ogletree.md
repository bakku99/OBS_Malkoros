# Sir Roland Ogletree
See also: [[Sir Roland Ogletree]]
- Species: Variant-Human
- Level: 10
- Class: Warlock (Pact of the Blade) - Level 5, Paladin (Oath of the Crown) - Level 5
- Alignment: Lawful Neutral
- Patron deity: Atotz, Goddess of Luck
- Secrets: Is a Werewolf Lycanthrope
- Motives: Serve his friends as a loyal protector and help those in need, as long as serves Lady Luck and his personal tenets. Wants to find out the origins of Lycanthropy in Malkoros. Unsure if he wants his curse removed or not.

## Backstory
"Sir Roland was originally an NPC, named Yaya, that the party met in a forest on a side quest, but through roleplay, Erci was able to convince him to join the party due to his fondness over their shared nickname. This was originally going to be a short-lived joke, but I soon found myself developing a lucrative and interesting backstory for Yaya and have now cemented him as a staple of the party. Though the party did not know this at the time of introduction, the village in the forest that Yaya lived in was a rogue settlement of Good werewolves. His backstory involves being raised as an orphan boy by this village of werewolves, and since werewolves are unable to control their bloodlust when transformed under a full moon, they would lock themselves or Yaya up during those nights for his own safety. After Yaya became of age, he made his choice to partake in the village's ritual of becoming a werewolf himself. This involved his father-figure of the village taking him to a remote ritual site within the forest, where his father locked himself in a cage until he transformed. Yaya willingly allowed the werewolf to lacerate him, but something unintentional transpired... an artery was knicked, and Yaya began to bleed out. Moments away from death, lying down and staring at the night sky, he saw the Goddess of Luck (often referred to as Lady Luck), Atotz, approach him and save his life. For this, he swore fealty to the chaotic neutral Goddess, and thus often acts on a whim and believes that Lady Luck is always on his side. This was the moment that Yaya took Atotz as his Warlock Patron, which allowed for him to develop his powers."

