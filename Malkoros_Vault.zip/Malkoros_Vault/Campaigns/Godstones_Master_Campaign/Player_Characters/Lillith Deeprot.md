# Lillith Deeprot
See also: [[Lillith Deeprot]]
- Species: Variant-Human
- Level: 10
- Class: Wizard (Necromancy) - Level 10
- Alignment: Chaotic Neutral
- Patron deity: Othys, God of Death
- Motives: Seek out the Books of Othys, find her father, prove herself to Othys

## Backstory
 "My father was one of the most feared necromancers in my city. I would spend every waking moment soaking up his knowledge like a sponge. He was eventually banished from our land and was forced to become a recluse in his old age. I was always strongly advised not to look for him, of course I wouldn’t listen. I left my mother a note of sorrow for I knew how badly this would hurt her. I began my journey to this “tower” and after some days I found it. For 20 years now I myself have become a recluse, following my father’s footsteps. Yet I haven’t seen or heard my father in here, it’s to my knowledge that he’s passed. I now make it my life goal to become even more powerful and finish what he started."