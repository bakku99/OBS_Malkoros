# Godstones Story Summary

