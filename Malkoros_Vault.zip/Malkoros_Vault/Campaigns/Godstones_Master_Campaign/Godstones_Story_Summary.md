# Godstones Story Summary



