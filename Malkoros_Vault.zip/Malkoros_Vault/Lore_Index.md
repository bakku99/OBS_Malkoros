# 📚 Lore Index

## Core Lore

- [[Lore/Arcane_Circle_of_Enlightment|Arcane Circle of Enlightment]]
- [[Lore/Genesis|Genesis]]
- [[Lore/Geography|Geography]]
- [[Lore/Geopolotitical_info|Geopolotitical info]]
- [[Lore/Gods|Gods]]
- [[Lore/Pantheon_Structure|Pantheon Structure]]
- [[Lore/Fellowships|Fellowships]]
- [[Lore/Symbols|Symbols]]
- [[Lore/Granted_Powers|Granted Powers]]
- [[Lore/Lesser_Deities|Lesser Deities]]
- [[Lore/Lore_Summary|Lore Summary]]
- [[Lore/Malkoros_Calendar|Malkoros Calendar]]
- [[Lore/Timeline|Timeline]]

## Elemental Deities
- [[Lore/Elemental_Deities/Eirsyr|Eirsyr]]
- [[Lore/Elemental_Deities/Myrradyn|Myrradyn]]
- [[Lore/Elemental_Deities/Nysthariel|Nysthariel]]
- [[Lore/Elemental_Deities/Pyrius|Pyrius]]
- [[Lore/Elemental_Deities/Thavax|Thavax]]
- [[Lore/Elemental_Deities/Zephrayl|Zephrayl]]

## Greater Deities
- [[Lore/Greater_Deities/Atotz|Atotz]]
- [[Lore/Greater_Deities/Hostus|Hostus]]
- [[Lore/Greater_Deities/Ineas|Ineas]]
- [[Lore/Greater_Deities/Othys|Othys]]
- [[Lore/Greater_Deities/Solanis|Solanis]]
- [[Lore/Greater_Deities/Therassor|Therassor]]
- [[Lore/Greater_Deities/Uztix|Uztix]]

## Lower Planes Deities
- [[Lore/Lower_Planes_Deities/Azhadûn|Azhadûn]]
- [[Lore/Lower_Planes_Deities/Ulvaarak|Ulvaarak]]

## Lesser Deities
- [[Lore/Lesser_Deities/Kaelis|Kaelis]]
- [[Lore/Lesser_Deities/Lunessa|Lunessa]]
- [[Lore/Lesser_Deities/Seramara|Seramara]]
- [[Lore/Lesser_Deities/Tahrun|Tahrun]]
- [[Lore/Lesser_Deities/Vaelreth|Vaelreth]]
- [[Lore/Lesser_Deities/Vandryl|Vandryl]]
- [[Lore/Lesser_Deities/Xexas|Xexas]]